<?php
    $arq = fopen("alunos.txt","a") or die("Erro ao abrir o arquivo");
     echo" <table border='1' cellpadding='5'>";  
    while(!feof($arq)){
        $linha=fgets($arq);
    }
    fclose($arq);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exibir.php</title>
</head>
<body>
   

    <form action="index.html" method="post">
        <button type="submit">Voltar</button>
    </form>
</body>
</html>